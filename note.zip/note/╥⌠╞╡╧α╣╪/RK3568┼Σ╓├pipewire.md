*PipeWire是一个新的底层多媒体框架。它专注于同时为音频和视频提供**低延迟的**录制和回放，Pipewire支持所有接入PulseAudio，JACK，ALSA和GStreamer的程序。*

[Linux音频（1）：alsa架构和RK3588 PCM实例 - ArnoldLu - 博客园 (cnblogs.com)](https://www.cnblogs.com/arnoldlu/p/18057519)