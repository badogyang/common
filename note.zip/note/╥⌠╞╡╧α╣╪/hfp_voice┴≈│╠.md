---
标题: hfp voice流程
概要：PCM概念/平台PCM配置/模组HW  interface/format/role
类别: 
- bluez
- linux
- 音频

---



![img](./img/SouthEast-1685684312587-4.png)