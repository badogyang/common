一开始只配置了CONFIG_GPIO_SYSFS=y，在/sys/class/gpio下面未生效，需要添加CONFIG_EXPERT=y才行

![c2bd32ee7a77d58bbd65949a198b172](./img/c2bd32ee7a77d58bbd65949a198b172.png)