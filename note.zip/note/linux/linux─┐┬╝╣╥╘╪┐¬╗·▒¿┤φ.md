![](./img/e710298d6edd42f5b29487b3507a19c7.png)

报错是没有找到ext4文件系统，之前在格式化的时候我选择的是ntfs，所以这里也要改为ntfs

vim /etc/fstab

![d5fd9566d2c6630747f65eaab302456](./img/d5fd9566d2c6630747f65eaab302456.png)