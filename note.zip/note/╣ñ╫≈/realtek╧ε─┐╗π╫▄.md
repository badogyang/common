    [ "${PRODUCT_NAME}" = "FCS850RBACMD" ] || \
​    [ "${PRODUCT_NAME}" = "FCS850RACMD" ] || \
​    [ "${PRODUCT_NAME}" = "FCS866RBAAMD" ] || \
​    [ "${PRODUCT_NAME}" = "FCS866RAAMD" ] || \
​    [ "${PRODUCT_NAME}" = "FCE863RBAAMD" ] || \
​    [ "${PRODUCT_NAME}" = "FCE863RAAMD" ] || \
​    [ "${PRODUCT_NAME}" = "FCS950RAAMD" ] || \
​    [ "${PRODUCT_NAME}" = "FCS940RAAMD" ] || \
​    [ "${PRODUCT_NAME}" = "FCS940RABMD" ] || \
​    [ "${PRODUCT_NAME}" = "FCS945RAAMD" ] || \
​    [ "${PRODUCT_NAME}" = "FCS852RAAMD" ] || \
​    [ "${PRODUCT_NAME}" = "FCS852RBAAMD" ] || \
​    [ "${PRODUCT_NAME}" = "FCU743RAAMD" ] 

1. realtek ec20陪测版本维护（FCS940R/FCS950R/FCS850R/FCS852R）
2. realtek 送测问题处理（HFP/拉距/耗流/共存等）
3. realtek RK3568陪测版本（FCE863R在计划做）
4. realtek 客户问题处理/feature list维护