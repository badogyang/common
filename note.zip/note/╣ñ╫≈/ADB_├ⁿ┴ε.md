



```
PS C:\Users\noah.yang> adb devices -l
List of devices attached
?                      device product:rk3568-linux model:Nexus_4 device:mako transport_id:13
?                      device product:rk3568-linux model:Nexus_4 device:mako transport_id:12

PS C:\Users\noah.yang> adb -t 13 shell
```

