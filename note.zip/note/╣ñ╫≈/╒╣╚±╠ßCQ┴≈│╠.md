[IBM Rational ClearQuest-SPRDCSS/SPCSS (unisoc.com)](http://spcss.unisoc.com:2008/cqweb/)

```
网址： http://spcss.unisoc.com:2008/cqweb/

CQ User Name: quectel_wifi
New Password: $IBumYcAZn6I3Nnfb*9u
```

![image-20240520144534006](./img/image-20240520144534006.png)

![image-20240520144755067](./img/image-20240520144755067.png)



![image-20240520145509560](./img/image-20240520145509560.png)



添加log附件

![image-20240520145534778](./img/image-20240520145534778.png)

记录CQ号点击右上角保存按钮即可提交case



提交后邮件也可以接收到提交成功的邮件

![image-20240520145739284](./img/image-20240520145739284.png)

![image-20240520145832226](./img/image-20240520145832226.png)





**进入沟通页面一开始是不可以进行沟通的，需要先点击modify才可以进行编辑。**

![image-20240520145914559](./img/image-20240520145914559.png)

如果不能直接点击modify，需要先更改状态，reopen此单

![image-20240520150629208](./img/image-20240520150629208.png)

还可以在这里进行其他的open close等操作

![image-20240520145956067](./img/image-20240520145956067.png)



建立查询

![image-20240520150124774](./img/image-20240520150124774.png)