# 公司mac地址

```
https://knowledge.quectel.com/download/attachments/184181434/oui.txt?api=v2

mac号段查询网址：https://macaddresschanger.com/bluetooth-mac-lookup
```

