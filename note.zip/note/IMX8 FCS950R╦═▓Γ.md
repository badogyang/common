# IMX8 FCS950R送测



Yocto

vim /home/noah/project/Yocto/sources/meta-imx/meta-bsp/recipes-kernel/linux/linux-imx/defconfig_external



