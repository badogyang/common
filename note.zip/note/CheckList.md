送测checklist

- [ ] 蓝牙enable
- [ ] 蓝牙mac
- [ ] 扫描
- [ ] 配对
- [ ] 音乐sink+source
- [ ] 通话hf
- [ ] gattc 收发
- [ ] gatts 收发

